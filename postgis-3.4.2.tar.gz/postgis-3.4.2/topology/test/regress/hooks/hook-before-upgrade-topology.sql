SELECT topology.createTopology('upgrade_test');

