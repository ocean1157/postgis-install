DROP EVENT TRIGGER IF EXISTS trg_autovac_disable;
DROP FUNCTION IF EXISTS trg_test_disable_table_autovacuum();
