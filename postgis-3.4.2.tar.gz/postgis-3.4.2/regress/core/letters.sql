SELECT ST_Area(ST_Letters('10'));
